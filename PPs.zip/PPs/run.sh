#!/bin/bash
for pp in C.pbe-n-kjpaw_psl.1.0.0.UPF\
 C.pbe-n-rrkjus_psl.1.0.0.UPF\
 C.pz-n-kjpaw_psl.0.1.UPF\
 C.pz-n-rrkjus_psl.0.1.UPF; do
cat > vc-relax.$pp.in <<EOF
&CONTROL
calculation = 'vc-relax'
restart_mode = 'from_scratch'
pseudo_dir = './Pseudo/'
outdir = './output/'
prefix = 'graphene'
/
&SYSTEM
ibrav = 4
a = 2.47
c = 7.80
nat = 2
ntyp = 1
occupations = 'smearing'
smearing = 'mv'
degauss = 0.02
ecutwfc = 40
/
&ELECTRONS
mixing_beta = 0.7
conv_thr = 1.0D-9
/
&IONS
ion_dynamics = 'bfgs'
/
&CELL
cell_dynamics = 'bfgs'
press_conv_thr = 0.05
cell_dofree = '2Dxy'
/
ATOMIC_SPECIES
C 12.01017  $pp
ATOMIC_POSITIONS (crystal)
C  0.6  0.3  0.5
C  0.3  0.6  0.5
K_POINTS (automatic)
  10 10 1 0 0 0
EOF
mpirun -np 2 pw.x <vc-relax.$pp.in> vc-relax.$pp.out
done
